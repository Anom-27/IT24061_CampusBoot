import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Maps a URL path to a method.
 * The specification names the element path(), but the starter code uses the
 * shortcut @Route("/hello"), which Java only allows for an element named value().
 * So both are supported: @Route("/hello") and @Route(path = "/hello").
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Route {
    String path() default "";
    String value() default "";
}
