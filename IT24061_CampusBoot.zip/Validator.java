import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/** Validates @Range fields of any object. */
public class Validator {

    public static List<String> validate(Object obj) {
        List<String> violations = new ArrayList<>();
        for (Field field : obj.getClass().getDeclaredFields()) {
            Range range = field.getAnnotation(Range.class);
            if (range == null) {
                continue;
            }
            if (field.getType() != int.class && field.getType() != Integer.class) {
                continue; // @Range supports int fields only
            }
            try {
                field.setAccessible(true);
                int value = ((Number) field.get(obj)).intValue();
                if (value < range.min() || value > range.max()) {
                    violations.add(field.getName() + " - " + range.message() + " (actual: " + value + ")");
                }
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        return violations;
    }
}
