import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Maps a request path to a @Route method and invokes it. */
public class Router {

    public static String dispatch(Container c, String path) {
        for (Object bean : c.getBeans()) {
            for (Method method : bean.getClass().getDeclaredMethods()) {
                Route route = method.getAnnotation(Route.class);
                if (route == null) {
                    continue;
                }
                String routePath = route.path().isEmpty() ? route.value() : route.path();
                if (routePath.equals(path)) {
                    try {
                        method.setAccessible(true);
                        return (String) method.invoke(bean);
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        throw new RuntimeException("Cannot invoke route " + path, e);
                    }
                }
            }
        }
        return "404 Not Found: " + path;
    }
}
